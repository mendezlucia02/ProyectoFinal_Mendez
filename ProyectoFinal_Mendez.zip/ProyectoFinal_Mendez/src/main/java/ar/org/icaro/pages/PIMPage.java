package ar.org.icaro.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class PIMPage extends BasePage {

    private By employeeNameInput =
            By.xpath("//label[text()='Employee Name']/following::input[1]");

    private By searchButton =
            By.xpath("//button[@type='submit']");

    private By noRecordsMessage =
            By.xpath("//span[contains(text(),'No Records Found')]");

    private By pimHeader =
            By.xpath("//h6[text()='PIM']");

    private By employeeResults =
            By.cssSelector(".oxd-table-body");

    public PIMPage(WebDriver driver) {
        super(driver);
    }

    public void searchEmployeeByName(String name) {
        type(employeeNameInput, name);
        click(searchButton);
    }

    public boolean hasResults() {
        return isElementVisible(employeeResults);
    }

    public boolean isNoRecordsDisplayed() {
        return isElementVisible(noRecordsMessage);
    }

    public boolean isOnPIMPage() {
        return isElementVisible(pimHeader);
    }
}
