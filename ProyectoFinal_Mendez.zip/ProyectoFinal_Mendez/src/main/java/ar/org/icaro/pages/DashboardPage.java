package ar.org.icaro.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class DashboardPage extends BasePage {

    private By pimMenu = By.xpath("//span[text()='PIM']");
    private By dashboardHeader = By.xpath("//h6[text()='Dashboard']");
    private By userDropdown = By.cssSelector(".oxd-userdropdown-tab");
    private By logoutOption = By.xpath("//a[text()='Logout']");

    public DashboardPage(WebDriver driver) {
        super(driver);
    }

    public void goToPIM() {
        click(pimMenu);
    }

    public void logout() {
        click(userDropdown);
        click(logoutOption);
    }

    public boolean isOnDashboard() {
        return isElementVisible(dashboardHeader);
    }

    public String getHeaderText() {
        return getText(dashboardHeader);
    }
}