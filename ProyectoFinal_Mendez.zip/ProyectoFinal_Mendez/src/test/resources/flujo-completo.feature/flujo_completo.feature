Feature: Flujo completo en OrangeHRM

  Scenario: Login exitoso
    Given estoy en la página de login
    When ingreso usuario y contraseña válidos
    Then debería estar en el dashboard

  Scenario: Buscar empleado
    Given estoy en la página de login
    When ingreso usuario y contraseña válidos
    And navego al módulo PIM
    And busco al empleado John
    Then debería obtener resultados

  Scenario: Flujo completo E2E
    Given estoy en la página de login
    When ingreso usuario y contraseña válidos
    And navego al módulo PIM
    And busco al empleado John
    And cierro sesión
    Then debería volver a la página de login