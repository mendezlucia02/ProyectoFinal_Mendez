package steps;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import ar.org.icaro.pages.DashboardPage;
import ar.org.icaro.pages.LoginPage;
import ar.org.icaro.pages.PIMPage;

import static org.testng.Assert.assertTrue;

public class FlujoPrincipalSteps {

    private LoginPage loginPage;
    private DashboardPage dashboardPage;
    private PIMPage pimPage;

    private void initializePages() {
        loginPage = new LoginPage(Hooks.driver);
        dashboardPage = new DashboardPage(Hooks.driver);
        pimPage = new PIMPage(Hooks.driver);
    }

    @Given("estoy en la página de login")
    public void estoyEnLaPaginaDeLogin() {

        initializePages();

        loginPage.goTo();

        assertTrue(
                loginPage.isOnLoginPage(),
                "No se encuentra en la página de Login"
        );
    }

    @When("ingreso usuario y contraseña válidos")
    public void ingresoUsuarioYContrasenaValidos() {

        loginPage.loginAs("Admin", "admin123");
    }

    @Then("debería estar en el dashboard")
    public void deberiaEstarEnElDashboard() {

        assertTrue(
                dashboardPage.isOnDashboard(),
                "No se encuentra en el Dashboard"
        );
    }

    @When("navego al módulo PIM")
    public void navegoAlModuloPIM() {

        dashboardPage.goToPIM();

        assertTrue(
                pimPage.isOnPIMPage(),
                "No se encuentra en PIM"
        );
    }

    @When("busco al empleado John")
    public void buscoAlEmpleadoJohn() {

        pimPage.searchEmployeeByName("John");
    }

    @Then("debería obtener resultados")
    public void deberiaObtenerResultados() {

        assertTrue(
                pimPage.hasResults(),
                "No se encontraron resultados"
        );
    }

    @When("cierro sesión")
    public void cierroSesion() {

        dashboardPage.logout();
    }

    @Then("debería volver a la página de login")
    public void deberiaVolverALaPaginaDeLogin() {

        assertTrue(
                loginPage.isOnLoginPage(),
                "No volvió a la página de Login"
        );
    }
}