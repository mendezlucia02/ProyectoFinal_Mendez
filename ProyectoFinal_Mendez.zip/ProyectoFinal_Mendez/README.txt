Proyecto Final Integrador — Test Automation OrangeHRM

Autor: Lucía Méndez - 44.08.766
Modalidad: Individual

//Objetivo://

-Automatizar un flujo E2E (end-to-end) completo sobre la aplicación demo [OrangeHRM](https://opensource-demo.orangehrmlive.com/), integrando Programación Orientada a Objetos, Selenium WebDriver, el patrón Page Object Model (POM), Gherkin, BDD y Cucumber.

//Flujo automatizado: "LOGIN → DASHBOARD → BUSCAR EMPLEADO → LOGOUT"//

Tecnologías y versiones utilizadas

| Herramienta | Versión |
|---          |---|
| JDK         | 25.0.3 |
| Maven       | (la que gestiona el proyecto vía "pom.xml") |
| Selenium WebDriver | 4.10.0 |
| Cucumber Java | 7.13.0 |
| Cucumber TestNG | 7.13.0 |
| TestNG      | 7.8.0 |
| IDE         | IntelliJ IDEA |
| Navegador probado | Google Chrome 153.0.8010.53 |

//Estructura del proyecto//

-----------------------
ProyectoFinal_Mendez/
├── pom.xml
├── drivers/
│   └── chromedriver.exe
├── src/
│   ├── main/java/ar/org/icaro/pages/
│   │   ├── BasePage.java
│   │   ├── LoginPage.java
│   │   ├── DashboardPage.java
│   │   └── PIMPage.java
│   └── test/
│       ├── java/
│       │   ├── runner/
│       │   │   └── TestRunner.java
│       │   └── steps/
│       │       ├── Hooks.java
│       │       └── FlujoPrincipalSteps.java
│       └── resources/features/
│           └── flujo_completo.feature
```

//Decisiones de diseño//

//Page Object Model (POM)//

Cada pantalla de la aplicación está modelada como una clase independiente ("LoginPage", "DashboardPage", "PIMPage"), separando los -locators- y las -acciones- de la lógica de los tests. Esto significa que si un elemento cambia en la aplicación real, solo hay que corregirlo en un lugar (el Page Object correspondiente), y no en cada test que lo usa.

//Herencia//

Las tres clases de página ("LoginPage", "DashboardPag", "PIMPage") heredan ("extends") de una clase base común, **"BasePage"**, que centraliza las acciones genéricas de Selenium reutilizadas en todas las páginas:

- "click(By locator)"
- "type(By locator, String texto)"
- "getText(By locator)"
- "isElementVisible(By locator)"
- "waitForUrlContains(String texto)"
- "waitForElementToDisappear(By locator)"

Esto evita duplicar la lógica de espera y manejo de "WebDriver" en cada clase.

//Encapsulamiento//

Los locators ("By") y el "WebDriver" están declarados como atributos "private" o "protected" en cada clase, nunca "public". Solo se exponen a través de métodos públicos con nombres que describen la acción de negocio (por ejemplo, "loginAs(usuario, contraseña)" en lugar de exponer directamente el input y el botón).

// BDD / Gherkin / Cucumber

El comportamiento esperado se describe en lenguaje natural en "flujo_completo.feature", usando "Given/When/Then". Cada línea Gherkin está conectada a un método Java en "FlujoPrincipalSteps.java" mediante las anotaciones de Cucumber ("@Given", "@When", "@Then"), que a su vez utilizan los Page Objects para interactuar con el navegador.

### Hooks

"Hooks.java" centraliza el ciclo de vida del "WebDriver" con "@Before" (abre el navegador antes de cada escenario) y "@After" (lo cierra después), evitando repetir ese código en cada step y asegurando que el navegador se cierre incluso si un test falla.

## Escenarios cubiertos ("flujo_completo.feature")

1. Login exitoso — valida el login con credenciales válidas.
2. Buscar empleado — login, navegación al módulo PIM, y búsqueda de un empleado ("John").
3. Flujo completo E2E — login, búsqueda de empleado, logout, y validación de que se vuelve a la pantalla de login.

//Cómo ejecutar el proyecto//

//Requisito previo: ChromeDriver

Este proyecto usa Selenium 4.10.0, cuya detección automática de versión de Chrome (Selenium Manager) puede no reconocer versiones muy recientes del navegador. Por eso, el "chromedriver.exe" correspondiente a la versión de Chrome usada en el desarrollo (153.0.8010.x) está incluido en la carpeta "drivers/" del proyecto, y "Hooks.java" apunta a esa ruta de forma relativa:

----------------java
String driverPath = System.getProperty("user.dir") + "\\drivers\\chromedriver.exe";
System.setProperty("webdriver.chrome.driver", driverPath);
-----------------

Si quien ejecuta el proyecto tiene una versión de Chrome muy distinta a la 153.x, puede ser necesario reemplazar el "chromedriver.exe" de "drivers/" por la versión correspondiente, disponible en [Chrome for Testing](https://googlechromelabs.github.io/chrome-for-testing/#stable).

---------- Pasos

1. Clonar o descomprimir el proyecto.
2. Abrir en IntelliJ IDEA como proyecto Maven (las dependencias se descargan automáticamente).
3. Ejecutar "TestRunner.java" (botón derecho → Run), o desde la terminal:
   '''''''
   mvn clean test
  '''''''''

// Notas

- Credenciales de la aplicación: usuario "Admin", contraseña "admin123".
- El proyecto se probó contra la URL demo pública de OrangeHRM, que puede presentar tiempos de carga variables; por eso los "wait" están configurados en 15 segundos.